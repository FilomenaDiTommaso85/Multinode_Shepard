%% This function computes the Multinode Shepard method which associates to each interpolation point a
%% $m$-tuple $\sigma_j$

%% INPUT:
%% xn: vector of the x-coordinates of the nodes
%% yn: vector of the y-coordinates of the nodes
%% fn: vector of the function values at the nodes (xn,yn)
%% r: degree of the local polynomial interpolant
%% mu: power parameter
%% x: vector of the x-coordinate of the evalutation points
%% y: vector of the y-coordinate of the evalutation points

%% OUTUPUT
%% MO: values of the multinode Shepard operator at the points (x,y)
%% s: number of the $m$-tuples $\sigma_j$


%%%% AUTHORS:
%%%% F. Dell'Accio, F. Di Tommaso, F. Larosa

function [MO,s]=Multinode_Shepard2(xn,yn,fn,r,mu,x,y)
n=length(xn);
m=(r+1)*(r+2)/2; %% The corresponding number of points

%% Compute the Lebesgue measure of the rectangle $\Omega$ containing the nodes
x1=min(xn); x2=max(xn);
y1=min(yn); y2=max(yn);
MOmega=(x2-x1)*(y2-y1);

l=sqrt(((r+2)*(r+3)/2)*MOmega/n);%% The side of the square for the determination of the $m$-tuple $\sigma_j$

pow=powers(r); %% The powers of the bivariate monomial basis of total degree "deg"
mu=mu/2;

X_ind=1:n; %% indexes of the node set X
Xprime_ind=1:n; %% copy of the indexes of the node set X


%% Compute the Gram matrix in the monomial basis of degree $d$
BV=@(xnp,ynp,xg,yg) BivVand(xnp-xg,ynp-yg,r,pow);

s=0;
Num=0;
Den=0;


while ~isempty(Xprime_ind)
    %%%%% Compute the \sigma-tuple
    s=s+1;
    %%% x and y coordinate of the nodes in $N_i$
    xNi=xn(((xn>=xn(Xprime_ind(1))-l/2) & (xn<=xn(Xprime_ind(1))+l/2))& ((yn>=yn(Xprime_ind(1))-l/2) & (yn<=yn(Xprime_ind(1))+l/2)));
    yNi=yn(((xn>=xn(Xprime_ind(1))-l/2) & (xn<=xn(Xprime_ind(1))+l/2))& ((yn>=yn(Xprime_ind(1))-l/2) & (yn<=yn(Xprime_ind(1))+l/2)));
    %%% indexes of the nodes in $N_i$ in the initial set of points
    iNi=X_ind(((xn>=xn(Xprime_ind(1))-l/2) & (xn<=xn(Xprime_ind(1))+l/2))& ((yn>=yn(Xprime_ind(1))-l/2) & (yn<=yn(Xprime_ind(1))+l/2)));
    k=1;
    cardNi=length(iNi); %% compute the cardinality of the set $N_i$
    while cardNi<(r+2)*(r+3)/2
        xNi=xn(((xn>=xn(Xprime_ind(1))-l/2*(1+k/10)) & (xn<=xn(Xprime_ind(1))+l/2*(1+k/10)))& ((yn>=yn(Xprime_ind(1))-l/2*(1+k/10)) & (yn<=yn(Xprime_ind(1))+l/2*(1+k/10))));
        yNi=yn(((xn>=xn(Xprime_ind(1))-l/2*(1+k/10)) & (xn<=xn(Xprime_ind(1))+l/2*(1+k/10)))& ((yn>=yn(Xprime_ind(1))-l/2*(1+k/10)) & (yn<=yn(Xprime_ind(1))+l/2*(1+k/10))));
        iNi=X_ind(((xn>=xn(Xprime_ind(1))-l/2*(1+k/10)) & (xn<=xn(Xprime_ind(1))+l/2*(1+k/10)))& ((yn>=yn(Xprime_ind(1))-l/2*(1+k/10)) & (yn<=yn(Xprime_ind(1))+l/2*(1+k/10))));
        cardNi=length(iNi);
        k=k+1;
    end
    
    %% Order the points in a [xn(Xprime_ind(1))-h,xn(Xprime_ind(1))+h] x [yn(Xprime_ind(1))-k,yn(Xprime_ind(1))+k]
    %% in increasing order
    Dn=(xNi-xn(Xprime_ind(1))).^2+(yNi-yn(Xprime_ind(1))).^2;
    [~,indexes]=sort(Dn);
    indexes=iNi(indexes);
    
    %%% Extract the nearest points to the first of the list X^{\prime} %%%
    xnp=xn(indexes);
    ynp=yn(indexes);
    
    %%% Compute the barycenter of the set of nearest points
    xb=sum(xnp)/cardNi;
    yb=sum(ynp)/cardNi;
    
    
    %% Compute the Gram matrix
    V=BV(xnp,ynp,xb,yb);
    
    %%%%% Extraction of the subset of Leja points
    [~,~,P]=lu(V,'vector');
    ind=P(1:m);
    
    tps=indexes(ind);
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%
    
    %%% Remove from  Xprime_ind the used indexes
    lia=ismember(Xprime_ind,tps);
    Xprime_ind=Xprime_ind(lia==0);
    
    %%%% Compute the multinode operator
    xtps=xn(tps);
    ytps=yn(tps);
    ftps=fn(tps);
    xb=sum(xtps)/m; %% The barycenter of the interpolation points
    yb=sum(ytps)/m;
    
    
    V=BV(xtps,ytps,xb,yb); %% The bivariate Vandermonde matrix centered at (xg,yg) and evaluated at the interpolation nodes
    coeff=V\ftps; %% The coefficients of the interpolation polynomial
    
    pb=BV(x,y,xb,yb);%% The bivariate Vandermonde matrix centered at (xg,yg) and evaluated at the evaluation points
    pol=pb*coeff;
    
    
    
    prodD=1;
    for j=1:m
        D=(xtps(j)-x).^2+(ytps(j)-y).^2;
        D(D==0)=eps;
        prodD=prodD.*(1./D).^mu;
    end
    
    prodD(prodD==Inf)=realmax/100; %%% Setting to avoid propagation error
    
    Num=Num+prodD.*pol;%% The numerator of the multinode operator
    Den=Den+prodD; %% The denominator of the multinode operator
    
end
MO=Num./Den;



