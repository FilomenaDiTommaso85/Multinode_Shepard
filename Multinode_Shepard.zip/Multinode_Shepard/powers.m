% Computing the powers of the bivariate monomial basis of total degree "d"
% by using the routine mono_next_grlex.m

% INPUT:
% d: total degree of the desired monomial powers

% OUTPUT:
% pow: matrix of the powers of bivariate monomial basis of total degree "d" 

%%%% EXAMPLE %%%%
% >> powV=pow(3)
% powV=[  0     0
%      0     1
%      1     0
%      0     2
%      1     1
%      2     0
%      0     3
%      1     2
%      2     1
%      3     0]

function pow=powers(d)
N=(d+1)*(d+2)/2;
pow=zeros(N,2);
pow(1,:)=[0,0];
for i=2:N
    pow(i,:) = mono_next_grlex(2,pow(i-1,:));
end