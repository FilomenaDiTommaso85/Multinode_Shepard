%% Demo for the reconstruction of the Stromboli Volcano including the Sciara del Fuoco of 2002 lava flow surface
%% from a data set of 95020 data stored in the file "Stromboli_nodes"
%% on the 2000 points of the file "Stromboli_evaluations".



%%%% AUTHORS:
%%%% F. Dell'Accio, F. Di Tommaso, F. Larosa

clear all
close all
clc


% EVALUATION POINTS %%%%
A=dlmread('Stromboli_evaluations');
x=A(:,1)/2;
y=A(:,2)/2;
Fe=A(:,3);
%%%%%%%%%%%%%%%%%%

% INTERPOLATION POINTS %%%%%
B=dlmread('Stromboli_nodes');
xn=B(:,1)/2;
yn=B(:,2)/2;
fn=B(:,3);
%%%%%%%%%%%%%%%%%%

mu=4; %% The power parameter


q=7; %%  number of additional points to select the $m$-tuple $\sigma_j$

UIControl_FontSize_bak = get(0, 'DefaultUIControlFontSize');
set(0, 'DefaultUIControlFontSize', 12);
r=menu('Degree of the local polynomial interpolant','r=1','r=2','r=3','r=4','r=5','r=6');


[MO1,s1]=Multinode_Shepard1(xn,yn,fn,r,q,mu,x,y); %% Multinode operator by using the first algorithm



[MO2,s2]=Multinode_Shepard2(xn,yn,fn,r,mu,x,y);%% Multinode operator by using the second algorithm


%%%% ABSOLUTE ERRORS FOR THE FIRST ALGORITHM
n=length(x);
absolute_error1=abs(MO1-Fe);
maxerr1=max(max(absolute_error1)); %% The maximum error
meanerr1=mean(mean(absolute_error1)); %% The mean error
RMSerr1=sqrt(1/n*mean(mean(absolute_error1.^2))); %% the mean squared error

%%%% ABSOLUTE ERRORS FOR THE SECOND ALGORITHM
absolute_error2=abs(MO2-Fe);
maxerr2=max(max(absolute_error2)); %% The maximum error
meanerr2=mean(mean(absolute_error2)); %% The mean error
RMSerr2=sqrt(1/n*mean(mean(absolute_error2.^2))); %% the mean squared error
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% RELATIVE ERRORS FOR THE FIRST ALGORITHMS
relative_error1=abs(MO1-Fe)./abs(Fe);
maxerr_rel1=max(max(relative_error1)); %% The maximum error
meanerr_rel1=mean(mean(relative_error1)); %% The mean error
RMSerr_rel1=sqrt(1/n*mean(mean(relative_error1.^2)));%% the mean squared error

%%%% RELATIVE ERRORS FOR THE SECOND ALGORITHMS
relative_error2=abs(MO2-Fe)./abs(Fe);
maxerr_rel2=max(max(relative_error2)); %% The maximum error
meanerr_rel2=mean(mean(relative_error2)); %% The mean error
RMSerr_rel2=sqrt(1/n*mean(mean(relative_error2.^2)));%% the mean squared error
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Alg={'Alg1';'Alg2'};
Number_mTuples=num2str([s1;s2],'%2.4e\n');
MAE=num2str([maxerr1;maxerr2],'%2.4e\n');
MEAE=num2str([meanerr1;meanerr2],'%2.4e\n');
RMSE=num2str([RMSerr1;RMSerr2],'%2.4e\n');
MAE_rel=num2str([maxerr_rel1;maxerr_rel2],'%2.4e\n');
MEAE_rel=num2str([meanerr_rel1;meanerr_rel2],'%2.4e\n');
RMSE_rel=num2str([RMSerr_rel1;RMSerr_rel2],'%2.4e\n');


Table=table(Alg,Number_mTuples,MAE,MEAE,RMSE,MAE_rel,MEAE_rel,RMSE_rel)



%%%% RECONSTRUCTION OF THE SURFACE %%%%%
nex=412;
ney=164;
%% Identification of the rectangle containing the data
x1=min(xn); x2=max(xn);
y1=min(yn); y2=max(yn);

%% Create the grid for evaluations
Xp=linspace(x1,x2,nex);
Yp=linspace(y1,y2,ney);
[xp,yp]=meshgrid(Xp,Yp);
xpe=xp(:);
ype=yp(:);

% Compute the multinode Shepard using the second algorithm
tic
[MO1,s1]=Multinode_Shepard1(xn,yn,fn,r,q,mu,xpe,ype);
toc

tic
[MO2,s2]=Multinode_Shepard2(xn,yn,fn,r,mu,xpe,ype);
toc


%% Reshape the result to plot the surface
MOP=reshape(MO2,ney,nex);

figure(2)
h = surf(xp, yp, flip(MOP), 'EdgeColor', 'none');
colormap(parula)
light('Position', [1 0 1], 'Style', 'infinite');
lighting gouraud;
material dull;
grid on;
set(gca, 'GridLineStyle', '--', 'LineWidth', 0.5);
set(gca, 'LineWidth', 1.5);
xlim([x1,x2])



