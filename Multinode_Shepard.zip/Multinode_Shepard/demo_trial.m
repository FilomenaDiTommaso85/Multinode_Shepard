%% Demo on computing the absolute, mean and mean squared errors using the multinode Shepard operator
%% when the target function $f$ is known


%%%% AUTHORS:
%%%% F. Dell'Accio, F. Di Tommaso, F. Larosa

clear all
clc
close all
warning off

N = 10000; %% The number of Interpolation points
n=100;   %% number of evaluation points
mu=4; %% The power parameter

[xn,yn] = Points('halton',N);

X=linspace(0,1,n);
Y=linspace(0,1,n);
[x,y]=meshgrid(X,Y);
x=x(:);
y=y(:);




f = @(x,y) 0.75*exp(-((9*x-2).^2+(9*y-2).^2)/4) ...
    +0.75*exp(-((9*x+1).^2/49+(9*y+1)/10)) ...
    +0.5*exp(-((9*x-7).^2+(9*y-3).^2)/4) ...
    -0.2*exp(-((9*x-4).^2+(9*y-7).^2));


fn = f(xn,yn); % function values at the nodes
Fe = f(x,y);  % function values at the evaluation points


q=7;
rmax=8;


for r=1:rmax
    m=(r+1)*(r+2)/2;
    
    tic
    [MO1,s1]=Multinode_Shepard1(xn,yn,fn,r,q,mu,x,y);
  toc
  
  tic
    [MO2,s2]=Multinode_Shepard2(xn,yn,fn,r,mu,x,y);
    toc
    %%%% ABSOLUTE ERRORS FOR THE FIRST ALGORITHM
    error1=abs(MO1-Fe);
    maxerr1(r,1)=max(error1); %% The maximum error
    meanerr1(r,1)=mean(error1); %% The mean error
    RMSerr1(r,1)=sqrt(1/n*mean(error1.^2)); %% the mean squared error
    
    %%%% ABSOLUTE ERRORS FOR THE SECOND ALGORITHM
    error2=abs(MO2-Fe);
    maxerr2(r,1)=max(error2); %% The maximum error
    meanerr2(r,1)=mean(error2); %% The mean error
    RMSerr2(r,1)=sqrt(1/n*mean(error2.^2)); %% the mean squared error
    
    m_tuples1(r,1)=s1;
    m_tuples2(r,1)=s2;
end


r=num2str((1:rmax)');
MAE_Alg1=num2str(maxerr1,'%2.4e\n');
MEAE_Alg1=num2str(meanerr1,'%2.4e\n');
RMSE_Alg1=num2str(RMSerr1,'%2.4e\n');


MAE_Alg2=num2str(maxerr2,'%2.4e\n');
MEAE_Alg2=num2str(meanerr2,'%2.4e\n');
RMSE_Alg2=num2str(RMSerr2,'%2.4e\n');

Table=table(r,MAE_Alg1,MAE_Alg2,MEAE_Alg1,MEAE_Alg2,RMSE_Alg1,RMSE_Alg2)


m_tuples_Alg1=num2str(m_tuples1,'%u');
m_tuples_Alg2=num2str(m_tuples2,'%u');
Table=table(r,m_tuples_Alg1,m_tuples_Alg2)

figure(1)
semilogy(1:rmax,maxerr1,'-ob',1:rmax,maxerr2,':dr','LineWidth',1.5)
legend('Alg1','Alg2')
figure(2)
semilogy(1:rmax,meanerr1,'-ob',1:rmax,meanerr2,':dr','LineWidth',1.5)
legend('Alg1','Alg2')
figure(3)
semilogy(1:rmax,RMSerr1,'-ob',1:rmax,RMSerr2,':dr','LineWidth',1.5)
legend('Alg1','Alg2')