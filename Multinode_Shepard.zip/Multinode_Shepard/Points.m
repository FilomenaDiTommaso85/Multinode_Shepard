%-------------------------------------------------------------------------%
%
% File:  Points(pointType,n)
%
% Goal:  returns a set of points
%
% Inputs:  pointType:  the type of points
%                  n:  number of points 
%
% Outputs: xn,yn:   x,y components of 2D points
%
% Calls on: haltonseq: by D. Dougherty, from MATLAB Central File Exchange
%
%-------------------------------------------------------------------------%
function [xn,yn] = Points(pointType,n)
switch pointType
    case 'halton'
        p=haltonset(2,'Skip',1);
        x = net(p,n);
    case 'sobol'
        p=sobolset(2);
        x=net(p,n);
    case 'rand'
        rand('seed',3)
        x = rand(n,2); 
    otherwise
        error(['Point type "' pointType '" not available'])
end 
xn = x(:,1); yn = x(:,2);
