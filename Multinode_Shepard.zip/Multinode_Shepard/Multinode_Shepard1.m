%% This function computes the Multinode Shepard method which associates to each interpolation point a 
%% $m$-tuple $\sigma_j$

%% INPUT:
%% xn: vector of the x-coordinates of the nodes
%% yn: vector of the y-coordinates of the nodes
%% fn: vector of the function values at the nodes (xn,yn)
%% deg: degree of the local polynomial interpolant
%% q: number of additional points to select the $m$-tuple $\sigma_j$
%% mu: power parameter
%% x: vector of the x-coordinate of the evalutation points
%% y: vector of the y-coordinate of the evalutation points

%% OUTUPUT
%% MO: values of the multinode Shepard operator at the points (x,y)
%% s: number of the $m$-tuples $\sigma_j$

%%%% AUTHORS:
%%%% F. Dell'Accio, F. Di Tommaso, F. Larosa


function [MO,s]=Multinode_Shepard1(xn,yn,fn,d,q,mu,x,y)
m=(d+1)*(d+2)/2; %% The corresponding number of points
pow=powers(d); %% The powers of the bivariate monomial basis of total degree "deg"
mu=mu/2;

n=length(xn);

%% Compute the Gram matrix in the monomial basis of degree $d$
BV=@(xnp,ynp,xg,yg) BivVand(xnp-xg,ynp-yg,d,pow);


Num=0;
Den=0;
s=0;
tpsv=zeros(n,m);

for i=1:n
    %% Order the points according to the increasing distances from xn(i)
    Dn=(xn(i)-xn).^2+(yn(i)-yn).^2; 
    [~,indexes]=sort(Dn);
    
 %%% Extract the nearest points %%%
    xnp=xn(indexes(1:m+q));
    ynp=yn(indexes(1:m+q));
    
    %%% Compute the barycenter of the set of nearest points
    xg=sum(xnp)/(m+q);
    yg=sum(ynp)/(m+q);    
      
    V=BV(xnp,ynp,xg,yg);
 
    %%%%% Extraction of the subset of Leja points
    [~,~,P]=lu(V,'vector');
    ind=P(1:m);

    %%%%%%%%%%%%
    tps=indexes(ind)';

    tpss=sort(tps);

    if ~ismember(tpss,tpsv,'rows') 
        s=s+1;
        tpsv(s,:)=tpss;

        %%%% Compute the multinode operator
        xtps=xn(tps);
        ytps=yn(tps);
        ftps=fn(tps);
        
        xb=sum(xtps)/m; %% The barycenter of the interpolation points
        yb=sum(ytps)/m;
       
        
       
        A=BV(xtps,ytps,xb,yb);%% The bivariate Vandermonde matrix centered at (xg,yg) 
                             %% and evaluated at the interpolation nodes
        coeff=A\ftps; %% The coefficients of the interpolation polynomial
        
    
        pb=BV(x,y,xb,yb);%% The bivariate Vandermonde matrix centered at (xg,yg) 
                         %% and evaluated at the evaluation points
        pol=pb*coeff;
        
        prodD=1;
        for j=1:m
            D=(xtps(j)-x).^2+(ytps(j)-y).^2;
            D(D==0)=eps;
            prodD=prodD.*(1./D).^mu;
        end
 
        Num=Num+prodD.*pol; %% The numerator of the multinode operator
        Den=Den+prodD; %% The denominator of the multinode operator
    end
end

MO=Num./Den;



