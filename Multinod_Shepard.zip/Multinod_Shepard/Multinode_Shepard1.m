%% This function computes the Multinode Shepard method which associates to each interpolation point a 
%% $m$-tuple $\sigma_j$

%% INPUT:
%% xn: vector of the x-coordinates of the nodes
%% yn: vector of the y-coordinates of the nodes
%% fn: vector of the function values at the nodes (xn,yn)
%% deg: degree of the local polynomial interpolant
%% q: number of additional points to select the $m$-tuple $\sigma_j$
%% mu: power parameter
%% x: vector of the x-coordinate of the evalutation points
%% y: vector of the y-coordinate of the evalutation points

%% OUTUPUT
%% MO: values of the multinode Shepard operator at the points (x,y)
%% s: number of the $m$-tuples $\sigma_j$




function [MO,s]=Multinode_Shepard1(xn,yn,fn,d,q,mu,x,y)
m=(d+1)*(d+2)/2; %% The corresponding number of points
pow=powers(d); %% The powers of the bivariate monomial basis of total degree "deg"

n=length(xn);

Num_MO=0;
Den_MO=0;
s=0;
tpsv=zeros(1,m);
for i=1:n
    %% We order the points according to the increasing distances from x_i
    Dn=sqrt((xn(i)-xn).^2+(yn(i)-yn).^2); 
    [~,indexes]=sort(Dn);
       
    %%% Extract the nearest points %%%
    xnp=xn(indexes(1:m+q));
    ynp=yn(indexes(1:m+q));
    
    %%% Compute the barycenter of the set of nearest points
    xg=sum(xnp)/(m+q);
    yg=sum(ynp)/(m+q);    
    
    %% Compute the Gram matrix in the monomial basis of degree $d$
    V=BivVand(xnp-xg,ynp-yg,d,pow);
    
    
    %%%%% Extraction of the subset of Leja points
    [~,~,P]=lu(V,'vector');
    ind=P(1:m);
    %%%%%%%%%%%%

    if ~ismember(sort(indexes(ind))',sort(tpsv,2),'rows') %% we check if the current tuples has not been considered yet 
        s=s+1;
        tps=indexes(ind);
        tpsv(s,:)=tps;

        %%%% Compute the multinode operator
        xtps=xn(tps);
        ytps=yn(tps);
        ftps=fn(tps);
        
        xb=sum(xtps)/m; %% The barycenter of the interpolation points
        yb=sum(ytps)/m;
        delta=max(sqrt((xtps-xb).^2+(ytps-yb).^2)); %%The scaling factor
        
        A=BivVand((xtps-xb)./delta,(ytps-yb)./delta,d,pow); %% The bivariate Vandermonde matrix centered at (xg,yg) 
                                                            %% and evaluated at the interpolation nodes
        
        coeff=A\ftps; %% The coefficients of the interpolation polynomial
        
        pb=BivVand((x-xb)./delta,(y-yb)./delta,d,pow);    %% The bivariate Vandermonde matrix centered at (xg,yg) 
                                                          %% and evaluated at the evaluation points
        
        pol=pb*coeff;
        
        D=zeros(length(x),m);
        for j=1:m
            D(:,j)=sqrt((xtps(j)-x).^2+(ytps(j)-y).^2);
        end
        D(D==0)=eps; %%% Setting which allows to evaluate the weight functions at the nodes avoiding a division by zero
        prodD=prod(D,2).^(-mu);
        
        Num_MO=Num_MO+prodD.*pol; %% The numerator of the multinode operator
        Den_MO=Den_MO+prodD; %% The denominator of the multinode operator
    end
end

MO=Num_MO./Den_MO;



