%% This function computes the bivariate Vandermonde matrix 

% INPUT:
% xsp: x-coordinate of the sample points.
% ysp: y-coordinate of the sample points
% d: degree of the Vandermonde matrix
% pow: powers of the bivariate monomial basis (matrix (d+1)*(d+2)/2 x 2)


% OUTPUT:
% A: Bivariate Vandermonde matrix of total degree "deg"

function A=BivVand(xps,yps,d,pow)

%% Computing the first deg+1 columns of the Vandermonde Matrix in reverse order.
V1 = repmat(xps, 1, d+1);
V1(:, d+1) = 1;
V1 = cumprod(V1, 2, 'reverse');

%% Computing the first deg+1 columns of the Vandermonde Matrix in reverse order.
V2 = repmat(yps, 1, d+1);
V2(:, d+1) = 1;
V2 = cumprod(V2, 2, 'reverse');


V1=V1(:,end:-1:1);
V2=V2(:,end:-1:1);

A=V1(:,pow(:,1)+1).*V2(:,pow(:,2)+1);


