%% Demo on computing the absolute, mean and mean squared errors using the multinode Shepard operator 
%% when the target function $f$ is known
clear all
clc
close all


d=7; %% The polynomial total degree

N = 1000; %% The number of Interpolation points
n=100; %% The number of evaluation points
mu=4; %% The power parameter

[xn,yn] = Points('halton',N);
[x,y] = Points('sobol',n);


f = @(x,y) 0.75*exp(-((9*x-2).^2+(9*y-2).^2)/4) ...
    +0.75*exp(-((9*x+1).^2/49+(9*y+1)/10)) ...
    +0.5*exp(-((9*x-7).^2+(9*y-3).^2)/4) ...
    -0.2*exp(-((9*x-4).^2+(9*y-7).^2));


fn = f(xn,yn); % function values at the nodes
Fe = f(x,y);  % function values at the evaluation points

q=7;

MO1=Multinode_Shepard1(xn,yn,fn,d,q,mu,x,y);

MO2=Multinode_Shepard2(xn,yn,fn,d,q,mu,x,y);

%%%% ABSOLUTE ERRORS FOR THE FIRST ALGORITHM
error1=abs(MO1-Fe);
maxerr1=max(error1); %% The maximum error
meanerr1=mean(error1); %% The mean error
RMSerr1=sqrt(1/n*mean(error1.^2)); %% the mean squared error

%%%% ABSOLUTE ERRORS FOR THE SECOND ALGORITHM
error2=abs(MO2-Fe);
maxerr2=max(error2); %% The maximum error
meanerr2=mean(error2); %% The mean error
RMSerr2=sqrt(1/n*mean(error2.^2)); %% the mean squared error

Alg={'Alg1';'Alg2'};
MAE=num2str([maxerr1;maxerr2],'%2.4e\n');
MEAE=num2str([meanerr1;meanerr2],'%2.4e\n');
RMSE=num2str([RMSerr1;RMSerr2],'%2.4e\n');
Table=table(Alg,MAE,MEAE,RMSE)
